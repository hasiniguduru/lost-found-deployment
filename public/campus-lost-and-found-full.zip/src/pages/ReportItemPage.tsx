import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  CheckCircle2,
  Building2,
  ArrowRight,
  HelpCircle,
  MapPin,
  Upload,
  Image as ImageIcon,
  Trash2,
} from 'lucide-react';
import {
  CAMPUS_ZONES,
  CollectionHub,
  ItemReport,
  hubsApi,
  itemsApi,
} from '../services/api';
import { useAuth } from '../context/AuthContext';
import { ResilientImage } from '../components/ResilientImage';

const SAMPLE_PHOTOS = [
  {
    label: 'Laptop',
    url: '/images/item_macbook_pro.jpg',
  },
  {
    label: 'Earbuds & Keys',
    url: '/images/item_airpods_case.jpg',
  },
  {
    label: 'Calculator',
    url: '/images/item_graphing_calc.jpg',
  },
  {
    label: 'Water Bottle',
    url: '/images/item_insulated_bottle.jpg',
  },
  {
    label: 'Leather Wallet',
    url: '/images/item_leather_wallet.jpg',
  },
];

export const ReportItemPage: React.FC = () => {
  const { user, refreshNotifications } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const initialMode = searchParams.get('mode') === 'FOUND' ? 'FOUND' : 'LOST';
  const [reportType, setReportType] = useState<'LOST' | 'FOUND'>(initialMode);
  const [hubs, setHubs] = useState<CollectionHub[]>([]);

  // Form fields
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ItemReport['category']>('Electronics');
  const [campusZone, setCampusZone] = useState<string>(CAMPUS_ZONES[0]);
  const [specificLocation, setSpecificLocation] = useState('');
  const [dateOccurred, setDateOccurred] = useState('2026-10-10 10:30');
  const [description, setDescription] = useState('');
  const [distinguishingFeatures, setDistinguishingFeatures] = useState('');
  const [verificationQuestion, setVerificationQuestion] = useState('');
  const [expectedVerificationHint, setExpectedVerificationHint] = useState('');
  const [hubId, setHubId] = useState('hub-lib-01');
  const [lockerBin, setLockerBin] = useState('');

  // Image upload state
  const [imageUrl, setImageUrl] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [createdItem, setCreatedItem] = useState<ItemReport | null>(null);

  useEffect(() => {
    const modeParam = searchParams.get('mode');
    if (modeParam === 'FOUND' || modeParam === 'LOST') {
      setReportType(modeParam);
    }
  }, [searchParams]);

  useEffect(() => {
    hubsApi.listHubs().then((list) => {
      setHubs(list);
      if (list.length > 0) setHubId(list[0].id);
    });
  }, []);

  const processSelectedFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setFieldErrors((prev) => ({
        ...prev,
        imageUrl: 'Please select a valid image file (PNG, JPG, WEBP).',
      }));
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setFieldErrors((prev) => ({
        ...prev,
        imageUrl: 'Image size must be under 10 MB.',
      }));
      return;
    }

    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next.imageUrl;
      return next;
    });

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const rawDataUrl = reader.result;
        const img = new Image();
        img.onload = () => {
          try {
            const maxWidth = 800;
            const maxHeight = 600;
            let width = img.width;
            let height = img.height;
            if (width > maxWidth || height > maxHeight) {
              const ratio = Math.min(maxWidth / width, maxHeight / height);
              width = Math.round(width * ratio);
              height = Math.round(height * ratio);
            }
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(img, 0, 0, width, height);
              const compressed = canvas.toDataURL('image/jpeg', 0.72);
              setImageUrl(compressed);
              setUploadedFileName(file.name);
              return;
            }
          } catch {
            // Fallback to original data URL
          }
          setImageUrl(rawDataUrl);
          setUploadedFileName(file.name);
        };
        img.onerror = () => {
          setImageUrl(rawDataUrl);
          setUploadedFileName(file.name);
        };
        img.src = rawDataUrl;
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleClearImage = () => {
    setImageUrl('');
    setUploadedFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFieldErrors({});
    setSubmitting(true);
    try {
      const created = await itemsApi.createItem({
        title,
        type: reportType,
        category,
        campusZone,
        specificLocation,
        dateOccurred,
        description,
        distinguishingFeatures,
        verificationQuestion,
        expectedVerificationHint,
        hubId: reportType === 'FOUND' ? hubId : undefined,
        lockerBin: reportType === 'FOUND' ? lockerBin : undefined,
        imageUrl: imageUrl || undefined,
      });
      setCreatedItem(created);
      await refreshNotifications();
    } catch (err: any) {
      if (err.response?.data?.fieldErrors) {
        setFieldErrors(err.response.data.fieldErrors);
      } else {
        setFieldErrors({
          general: err.response?.data?.message || 'Please check the required fields and try again.',
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (createdItem) {
    return (
      <div className="max-w-2xl mx-auto bg-white border border-emerald-200 rounded-2xl p-8 shadow-md space-y-6">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <div>
            <div className="text-xs font-semibold text-emerald-700">
              Report Confirmation · {createdItem.referenceCode}
            </div>
            <h1 className="font-display text-xl font-bold text-slate-900">
              {createdItem.type === 'FOUND'
                ? 'Found Item Registered & Drop-Off Receipt Ready'
                : 'Lost Item Report Published'}
            </h1>
          </div>
        </div>

        {/* Uploaded Item Image Preview on Confirmation */}
        <div className="aspect-16/9 max-h-56 w-full rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
          <ResilientImage
            src={createdItem.imageUrl}
            alt={createdItem.title}
            category={createdItem.category}
          />
        </div>

        <div className="p-5 bg-indigo-50/50 border border-indigo-100 rounded-xl space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-indigo-100 pb-2.5">
            <span className="text-slate-500">Tracking Number</span>
            <span className="font-mono font-bold text-indigo-700 tabular-nums">
              {createdItem.referenceCode}
            </span>
          </div>
          <div className="flex items-center justify-between border-b border-indigo-100 pb-2.5">
            <span className="text-slate-500">Item & Category</span>
            <span className="font-semibold text-slate-900">
              {createdItem.title} ({createdItem.category})
            </span>
          </div>
          <div className="flex items-center justify-between border-b border-indigo-100 pb-2.5">
            <span className="text-slate-500">Reported By</span>
            <span className="font-medium text-slate-800">
              {createdItem.reportedByName} ({createdItem.reportedByCampusId})
            </span>
          </div>
          {createdItem.type === 'FOUND' && (
            <>
              <div className="flex items-center justify-between border-b border-indigo-100 pb-2.5">
                <span className="text-slate-500">Assigned Collection Desk</span>
                <span className="font-semibold text-slate-900">
                  {createdItem.hubName} · {createdItem.lockerBin}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Drop-Off Receipt Code</span>
                <span className="font-mono text-sm font-bold text-emerald-700 tabular-nums">
                  {createdItem.submissionReceiptCode}
                </span>
              </div>
            </>
          )}
        </div>

        <div className="flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => {
              setCreatedItem(null);
              setTitle('');
              setSpecificLocation('');
              setDescription('');
              setDistinguishingFeatures('');
              setVerificationQuestion('');
              handleClearImage();
            }}
            className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50"
          >
            Submit Another Report
          </button>
          <button
            type="button"
            onClick={() => navigate('/items')}
            className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700"
          >
            <span>Browse All Items</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Mode Selection Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => {
            setReportType('LOST');
            setFieldErrors({});
          }}
          className={`p-5 rounded-2xl border text-left transition-all ${
            reportType === 'LOST'
              ? 'bg-amber-50/90 border-amber-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-amber-200'
          }`}
        >
          <div className="text-xs font-bold text-amber-700">Option 1 · Item Owner</div>
          <div className="font-display text-lg font-bold text-slate-900 mt-0.5">
            I Lost Something on Campus
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Post an alert for a misplaced item so finders and security desks can match it.
          </p>
        </button>

        <button
          type="button"
          onClick={() => {
            setReportType('FOUND');
            setFieldErrors({});
          }}
          className={`p-5 rounded-2xl border text-left transition-all ${
            reportType === 'FOUND'
              ? 'bg-emerald-50/90 border-emerald-400 shadow-sm'
              : 'bg-white border-slate-200 hover:border-emerald-200'
          }`}
        >
          <div className="text-xs font-bold text-emerald-700">Option 2 · Item Finder</div>
          <div className="font-display text-lg font-bold text-slate-900 mt-0.5">
            I Found an Item to Turn In
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Log a found item, select a Campus Collection Desk for drop-off, and get a receipt.
          </p>
        </button>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white border border-indigo-100 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900">
              {reportType === 'LOST' ? 'Lost Item Details' : 'Found Item & Desk Submission'}
            </h2>
            <p className="text-xs text-slate-500">
              Reporting as <span className="font-semibold text-slate-700">{user?.fullName}</span> ({user?.campusId})
            </p>
          </div>
        </div>

        {/* Section 1: Item & Location */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              What item was {reportType === 'LOST' ? 'lost' : 'found'}? *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Space Black 14-inch MacBook Pro or Blue Lanyard with Keys"
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:border-indigo-600"
            />
            {fieldErrors.title && (
              <p className="text-xs text-red-600 mt-1">{fieldErrors.title}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Category *
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as ItemReport['category'])}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl bg-white focus:border-indigo-600"
            >
              <option value="Electronics">Electronics</option>
              <option value="Campus ID & Keys">Campus ID & Keys</option>
              <option value="Textbooks & Lab Gear">Textbooks & Lab Gear</option>
              <option value="Apparel & Bags">Apparel & Bags</option>
              <option value="Personal Accessories">Personal Accessories</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Date & Approximate Time *
            </label>
            <input
              type="text"
              value={dateOccurred}
              onChange={(e) => setDateOccurred(e.target.value)}
              placeholder="YYYY-MM-DD HH:mm"
              className="w-full px-3.5 py-2.5 text-sm font-mono border border-slate-300 rounded-xl focus:border-indigo-600"
            />
            {fieldErrors.dateOccurred && (
              <p className="text-xs text-red-600 mt-1">{fieldErrors.dateOccurred}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Campus Building / Zone *
            </label>
            <select
              value={campusZone}
              onChange={(e) => setCampusZone(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl bg-white focus:border-indigo-600"
            >
              {CAMPUS_ZONES.map((zone) => (
                <option key={zone} value={zone}>
                  {zone}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Room or Exact Spot *
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={specificLocation}
                onChange={(e) => setSpecificLocation(e.target.value)}
                placeholder="e.g., 3rd Floor Reading Room Table 12"
                className="w-full pl-9 pr-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:border-indigo-600"
              />
            </div>
            {fieldErrors.specificLocation && (
              <p className="text-xs text-red-600 mt-1">{fieldErrors.specificLocation}</p>
            )}
          </div>
        </div>

        {/* Item Photo Upload Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-semibold text-slate-800">
              Item Photo (Upload from Device or Choose Sample)
            </label>
            {imageUrl && (
              <button
                type="button"
                onClick={handleClearImage}
                className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-700"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove Photo</span>
              </button>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          {imageUrl ? (
            <div className="p-4 bg-indigo-50/50 border border-indigo-200 rounded-2xl flex flex-col sm:flex-row items-center gap-4">
              <div className="w-full sm:w-44 aspect-4/3 rounded-xl overflow-hidden border border-indigo-200 bg-white shrink-0">
                <ResilientImage src={imageUrl} alt={title || 'Uploaded item preview'} category={category} />
              </div>
              <div className="flex-1 space-y-2 text-center sm:text-left">
                <div className="text-xs font-bold text-indigo-950">
                  {uploadedFileName ? `Uploaded: ${uploadedFileName}` : 'Selected Item Photo Ready'}
                </div>
                <p className="text-xs text-slate-600">
                  This photo will appear on the Dashboard and Browse Lost & Found cards to help identify the item.
                </p>
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-white border border-indigo-200 rounded-lg hover:bg-indigo-50"
                  >
                    Change Photo
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`cursor-pointer border-2 border-dashed rounded-2xl p-6 text-center transition-colors ${
                isDragging
                  ? 'border-indigo-600 bg-indigo-50/80'
                  : 'border-indigo-200 bg-indigo-50/30 hover:bg-indigo-50/60 hover:border-indigo-400'
              }`}
            >
              <div className="w-11 h-11 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto mb-2.5">
                <Upload className="w-5 h-5" />
              </div>
              <div className="text-xs font-bold text-slate-900">
                Click to upload a photo or drag and drop here
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Supports JPG, PNG, or WEBP up to 10 MB
              </p>
            </div>
          )}

          {/* Quick Sample Photo Picker for Fast Testing */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500">
              <ImageIcon className="w-3.5 h-3.5 text-indigo-500" />
              <span>Or pick a sample photo:</span>
            </span>
            {SAMPLE_PHOTOS.map((sample) => (
              <button
                key={sample.label}
                type="button"
                onClick={() => {
                  setImageUrl(sample.url);
                  setUploadedFileName(`${sample.label} (Sample)`);
                }}
                className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg border transition-colors ${
                  imageUrl === sample.url
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300 hover:text-indigo-700'
                }`}
              >
                {sample.label}
              </button>
            ))}
          </div>

          {fieldErrors.imageUrl && (
            <p className="text-xs text-red-600 mt-1">{fieldErrors.imageUrl}</p>
          )}
        </div>

        {/* Fixed Collection Hub Assignment (When Reporting a Found Item) */}
        {reportType === 'FOUND' && (
          <div className="p-5 bg-teal-50/70 border border-teal-200 rounded-2xl space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold text-teal-900">
              <Building2 className="w-4 h-4 text-teal-600" />
              <span>Fixed Campus Collection Desk Drop-Off</span>
            </div>
            <p className="text-xs text-teal-800">
              Choose which Campus Security Collection Desk you are turning this item into so the owner knows where to pick it up.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-teal-950 mb-1">
                  Collection Desk Location *
                </label>
                <select
                  value={hubId}
                  onChange={(e) => setHubId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs border border-teal-300 rounded-xl bg-white"
                >
                  {hubs.map((hub) => (
                    <option key={hub.id} value={hub.id}>
                      {hub.name} ({hub.roomLocation})
                    </option>
                  ))}
                </select>
                {fieldErrors.hubId && (
                  <p className="text-xs text-red-600 mt-1">{fieldErrors.hubId}</p>
                )}
              </div>
              <div>
                <label className="block text-xs font-semibold text-teal-950 mb-1">
                  Locker Bin (Optional — Auto-assigned if blank)
                </label>
                <input
                  type="text"
                  value={lockerBin}
                  onChange={(e) => setLockerBin(e.target.value)}
                  placeholder="e.g., Bin A-15"
                  className="w-full px-3.5 py-2 text-xs font-mono border border-teal-300 rounded-xl bg-white"
                />
              </div>
            </div>
          </div>
        )}

        {/* Description & Distinguishing Marks */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Description *
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the brand, color, case, condition, and any helpful details..."
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:border-indigo-600"
            />
            {fieldErrors.description && (
              <p className="text-xs text-red-600 mt-1">{fieldErrors.description}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1.5">
              Special Markings, Stickers, or Keychain Tags
            </label>
            <input
              type="text"
              value={distinguishingFeatures}
              onChange={(e) => setDistinguishingFeatures(e.target.value)}
              placeholder="e.g., Robotics Club sticker on the cover, brass key tag 402..."
              className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-xl focus:border-indigo-600"
            />
          </div>
        </div>

        {/* Ownership Verification Challenge */}
        <div className="p-5 bg-indigo-50/60 border border-indigo-100 rounded-2xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-indigo-950">
            <HelpCircle className="w-4 h-4 text-indigo-600" />
            <span>Ownership Verification Question</span>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1">
              Question to Verify the True Owner *
            </label>
            <p className="text-xs text-slate-500 mb-2">
              Ask a detail only the rightful owner can answer (such as lock-screen wallpaper, key stamp number, or name inside the cover).
            </p>
            <input
              type="text"
              value={verificationQuestion}
              onChange={(e) => setVerificationQuestion(e.target.value)}
              placeholder="e.g., What 3-digit number is stamped on the brass key?"
              className="w-full px-3.5 py-2.5 text-sm bg-white border border-indigo-200 rounded-xl focus:border-indigo-600"
            />
            {fieldErrors.verificationQuestion && (
              <p className="text-xs text-red-600 mt-1">
                {fieldErrors.verificationQuestion}
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-800 mb-1">
              Expected Answer (Visible Only to Campus Security Officers)
            </label>
            <input
              type="text"
              value={expectedVerificationHint}
              onChange={(e) => setExpectedVerificationHint(e.target.value)}
              placeholder="e.g., Stamped 402"
              className="w-full px-3.5 py-2.5 text-sm bg-white border border-indigo-200 rounded-xl focus:border-indigo-600"
            />
          </div>
        </div>

        {fieldErrors.general && (
          <p className="text-xs text-red-600">{fieldErrors.general}</p>
        )}

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={() => navigate('/items')}
            className="px-4 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 whitespace-nowrap shrink-0"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className={`px-5 py-2.5 text-xs font-semibold text-white rounded-xl transition-colors shadow-xs disabled:opacity-50 whitespace-nowrap shrink-0 ${
              reportType === 'FOUND'
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {submitting
              ? 'Submitting...'
              : reportType === 'FOUND'
              ? 'Submit Found Item & Get Drop-Off Receipt'
              : 'Post Lost Item Report'}
          </button>
        </div>
      </form>
    </div>
  );
};
