import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Search,
  PackageSearch,
} from 'lucide-react';
import {
  ItemReport,
  dashboardApi,
} from '../services/api';
import { useAuth } from '../context/AuthContext';
import { ResilientImage } from '../components/ResilientImage';
import { ClaimSubmissionModal } from '../components/ClaimSubmissionModal';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState({
    totalReports: 0,
    lostCount: 0,
    foundCount: 0,
    inCustodyCount: 0,
    returnedCount: 0,
    pendingClaimsCount: 0,
    approvedPickupsCount: 0,
  });
  const [recentItems, setRecentItems] = useState<ItemReport[]>([]);
  const [selectedItemForClaim, setSelectedItemForClaim] = useState<ItemReport | null>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const data = await dashboardApi.getSummary();
      setMetrics(data.metrics);
      setRecentItems(data.recentItems.slice(0, 3));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard, user?.role]);

  const getRoleWelcome = () => {
    if (user?.role === 'ADMIN_SECURITY') {
      return {
        greeting: `Welcome, ${user.fullName}`,
        subtitle: 'Campus Safety & Collection Desk Coordinator',
        description:
          'Review student ownership claims, issue pickup pass codes, and manage items stored across the 4 campus collection desks.',
      };
    }
    if (user?.role === 'FINDER') {
      return {
        greeting: `Welcome back, ${user.fullName}`,
        subtitle: 'Campus Finder & Community Reporter',
        description:
          'Found something on campus? Report the item here, drop it off at a designated Campus Security desk, and get a receipt code.',
      };
    }
    return {
      greeting: `Welcome back, ${user?.fullName || 'Student'}`,
      subtitle: `${user?.department || 'Campus Member'} · ID ${user?.campusId || ''}`,
      description:
        'Looking for a misplaced belonging? Search items held at our Campus Collection Desks or post a lost item alert.',
    };
  };

  const welcome = getRoleWelcome();

  const formatStatusLabel = (status: ItemReport['custodyStatus']) => {
    switch (status) {
      case 'REPORTED':
        return 'Reported Missing';
      case 'AWAITING_SUBMISSION':
        return 'Awaiting Desk Drop-off';
      case 'IN_CUSTODY':
        return 'At Campus Security Desk';
      case 'CLAIM_APPROVED':
        return 'Ready for Pickup';
      case 'RETURNED':
        return 'Returned to Owner';
    }
  };

  return (
    <div className="space-y-8">
      {/* Colorful Hero Banner */}
      <section className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-violet-700 text-white rounded-2xl p-7 sm:p-8 shadow-md flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        <div className="max-w-2xl space-y-2">
          <div className="text-xs font-semibold text-amber-300 tracking-wide">
            {welcome.subtitle}
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
            {welcome.greeting}
          </h1>
          <p className="text-sm text-indigo-100 leading-relaxed">
            {welcome.description}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => navigate('/items')}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-indigo-950 bg-white rounded-xl hover:bg-indigo-50 transition-colors shadow-xs whitespace-nowrap shrink-0"
          >
            <Search className="w-4 h-4 text-indigo-600" />
            <span>Browse All Items</span>
          </button>
          <button
            type="button"
            onClick={() =>
              navigate(
                user?.role === 'FINDER'
                  ? '/report?mode=FOUND'
                  : user?.role === 'ADMIN_SECURITY'
                  ? '/claims'
                  : '/report?mode=LOST'
              )
            }
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-slate-950 bg-amber-400 rounded-xl hover:bg-amber-300 transition-colors shadow-xs whitespace-nowrap shrink-0"
          >
            <span>
              {user?.role === 'FINDER'
                ? 'Submit Found Item'
                : user?.role === 'ADMIN_SECURITY'
                ? 'Review Pending Claims'
                : 'Report Lost Item'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* 4 Colorful Summary Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white border border-indigo-100 rounded-2xl p-5 shadow-xs flex items-start justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">
              Total Campus Reports
            </div>
            <div className="font-mono text-3xl font-bold text-indigo-700 tabular-nums mt-2">
              {loading ? '—' : metrics.totalReports}
            </div>
            <div className="text-xs text-slate-500 mt-1.5 font-medium">
              {metrics.lostCount} Lost · {metrics.foundCount} Found
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <PackageSearch className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-teal-100 rounded-2xl p-5 shadow-xs flex items-start justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">
              At Collection Desks
            </div>
            <div className="font-mono text-3xl font-bold text-teal-700 tabular-nums mt-2">
              {loading ? '—' : metrics.inCustodyCount}
            </div>
            <div className="text-xs text-slate-500 mt-1.5 font-medium">
              Stored in 4 Campus Hubs
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-amber-100 rounded-2xl p-5 shadow-xs flex items-start justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">
              Pending Verifications
            </div>
            <div className="font-mono text-3xl font-bold text-amber-600 tabular-nums mt-2">
              {loading ? '—' : metrics.pendingClaimsCount}
            </div>
            <div className="text-xs text-slate-500 mt-1.5 font-medium">
              {metrics.approvedPickupsCount} Ready for Pickup
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-emerald-100 rounded-2xl p-5 shadow-xs flex items-start justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500">
              Successfully Returned
            </div>
            <div className="font-mono text-3xl font-bold text-emerald-600 tabular-nums mt-2">
              {loading ? '—' : metrics.returnedCount}
            </div>
            <div className="text-xs text-slate-500 mt-1.5 font-medium">
              Verified Campus Owners
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </section>

      {/* Quick Action Modules (Cleanly Separates Features into Dedicated Pages) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <button
          type="button"
          onClick={() => navigate('/items')}
          className="text-left bg-gradient-to-br from-white to-indigo-50/60 border border-indigo-100 hover:border-indigo-300 rounded-2xl p-6 transition-all group shadow-xs"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-4">
            <Search className="w-5 h-5" />
          </div>
          <h2 className="font-display text-base font-bold text-slate-900 flex items-center justify-between">
            <span>Search & Filter Items</span>
            <ArrowRight className="w-4 h-4 text-indigo-600 group-hover:translate-x-1 transition-transform" />
          </h2>
          <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
            Browse all lost and found reports by category, campus building, or collection desk location.
          </p>
        </button>

        <button
          type="button"
          onClick={() => navigate('/hubs')}
          className="text-left bg-gradient-to-br from-white to-teal-50/60 border border-teal-100 hover:border-teal-300 rounded-2xl p-6 transition-all group shadow-xs"
        >
          <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center mb-4">
            <Building2 className="w-5 h-5" />
          </div>
          <h2 className="font-display text-base font-bold text-slate-900 flex items-center justify-between">
            <span>Fixed Collection Desks</span>
            <ArrowRight className="w-4 h-4 text-teal-600 group-hover:translate-x-1 transition-transform" />
          </h2>
          <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
            View operating hours, locker locations, and pickup pass check-out desks across campus.
          </p>
        </button>

        <button
          type="button"
          onClick={() => navigate('/claims')}
          className="text-left bg-gradient-to-br from-white to-amber-50/60 border border-amber-100 hover:border-amber-300 rounded-2xl p-6 transition-all group shadow-xs"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center mb-4">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h2 className="font-display text-base font-bold text-slate-900 flex items-center justify-between">
            <span>Ownership & Pickup Passes</span>
            <ArrowRight className="w-4 h-4 text-amber-600 group-hover:translate-x-1 transition-transform" />
          </h2>
          <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
            Track your ownership verification claims, approve matches, and view your Pickup Pass Codes.
          </p>
        </button>
      </section>

      {/* Recently Reported Campus Items (Spacious 3-Card Row) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900">
              Latest Campus Reports
            </h2>
            <p className="text-xs text-slate-500">
              Recent items reported lost or turned in at Campus Security desks
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/items')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
          >
            <span>See All {metrics.totalReports} Items</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {recentItems.map((item) => (
            <article
              key={item.id}
              className="bg-white border border-indigo-100 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              <div>
                <div className="aspect-4/3 w-full bg-slate-100 border-b border-slate-100 overflow-hidden">
                  <ResilientImage
                    src={item.imageUrl}
                    alt={item.title}
                    category={item.category}
                  />
                </div>
                <div className="p-5 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs">
                    <span
                      className={`font-bold ${
                        item.type === 'LOST' ? 'text-amber-600' : 'text-emerald-600'
                      }`}
                    >
                      {item.type}
                    </span>
                    <span aria-hidden="true" className="text-slate-300">
                      ·
                    </span>
                    <span className="text-slate-600 font-medium">{item.category}</span>
                    <span aria-hidden="true" className="text-slate-300">
                      ·
                    </span>
                    <span className="text-slate-500">{item.campusZone}</span>
                  </div>

                  <h3 className="font-display text-base font-bold text-slate-900 line-clamp-1">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="pt-2 text-xs text-slate-500">
                    <span className="font-semibold text-indigo-700">
                      {formatStatusLabel(item.custodyStatus)}
                    </span>
                    {item.hubName ? ` · ${item.hubName}` : ''}
                  </div>
                </div>
              </div>

              <div className="px-5 py-3.5 bg-indigo-50/40 border-t border-indigo-100/80 flex items-center justify-between gap-2">
                <span className="text-xs font-mono text-slate-500 tabular-nums">
                  {item.referenceCode}
                </span>
                {item.custodyStatus !== 'RETURNED' && (
                  <button
                    type="button"
                    onClick={() => setSelectedItemForClaim(item)}
                    className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap"
                  >
                    {item.type === 'FOUND' ? 'Claim This Item' : 'I Found This'}
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Ownership Claim Modal */}
      <ClaimSubmissionModal
        item={selectedItemForClaim}
        onClose={() => setSelectedItemForClaim(null)}
        onSuccess={loadDashboard}
      />
    </div>
  );
};
